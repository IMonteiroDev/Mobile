package com.example.calculadora;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Menu extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

//        handleOnClick();

        initializeButtons();
        setButtonListener();

        /*
        Button btnReturn = findViewById(R.id.btnVoltar);
        Button btnSum = findViewById(R.id.btnSum);
        Button btnMinus = findViewById(R.id.btnMinus);
        Button btnDiv = findViewById(R.id.btnDiv);
        Button btnMult = findViewById(R.id.btnMult);


        btnReturn.setOnClickListener(this);
        btnSum.setOnClickListener(this);
        btnMinus.setOnClickListener(this);
        btnDiv.setOnClickListener(this);
        btnMult.setOnClickListener(this);
        */
    }
/*
    private void handleOnClick(){
        Button btnReturn = findViewById(R.id.btnVoltar);
        btnReturn.setOnClickListener(new View.OnClickListener(){
            @Override
                    public void onClick(View v){
                        Intent returnHome = new Intent();
            }
        });
    }
*/
/*
    @Override
    public void onClick(View v) {
        if(v.getId() == R.id.btnVoltar){
            Intent returnHome = new Intent(this, MainActivity.class);
            startActivity(returnHome);
        }
        if (v.getId()== R.id.btnSum){
            Intent sum = new Intent(this, Sum.class);
            startActivity(sum);
        }
/*        if (v.getId()== R.id.btnMinus){
            Intent minus = new Intent(this, );
            startActivity(minus);
        }
        if (v.getId()== R.id.btnDiv){
            Intent div = new Intent(this, );
            startActivity(div);
        }
        if (v.getId()== R.id.btnMult){
            Intent multi = new Intent(this, );
            startActivity(multi);
        }

    }*/

    private void initializeButtons(){
        Button btnReturn = findViewById(R.id.btnVoltar);
        Button btnSum = findViewById(R.id.btnSum);
        Button btnMinus = findViewById(R.id.btnMinus);
        Button btnDiv = findViewById(R.id.btnDiv);
        Button btnMult = findViewById(R.id.btnMult);
    }

    private void setButtonListener(){
        btnReturn.setOnClickListener((v)-> openActivity(MainActivity.class));
        btnSum.setOnClickListener((v)-> openActivity(Sum.class));
//        btnMinus.setOnClickListener((v)-> openActivity(MainActivity.class));
//        btnDiv.setOnClickListener((v)-> openActivity(MainActivity.class));
//        btnMult.setOnClickListener((v)-> openActivity(MainActivity.class));
    }

    private void openActivity(Class<?> mainActivityClass) {
        Intent activity = new Intent(this, mainActivityClass);
        startActivity(activity);
    }
}