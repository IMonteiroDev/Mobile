package com.example.calculadora;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button buttonHome = findViewById(R.id.btnInicio);
        buttonHome.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.btnInicio) {
            Intent telaHome = new Intent(this, Menu.class);
            startActivity(telaHome);
        }
    }

    private void handleOnClick() {
        Button buttonAdicao = findViewById(R.id.btnAdicao);
        buttonAdicao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent telaCalcular = new Intent(MainActivity.this, Calcula.class);
                telaCalcular.putExtra("operacao","Somar");
                startActivity(telaCalcular);
            }
        });

        Button buttonSubtracao = findViewById(R.id.btnSubstracao);
        buttonSubtracao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent telaCalcular = new Intent(MainActivity.this, Calcula.class);
                telaCalcular.putExtra("operacao","Subtrair");
                startActivity(telaCalcular);
            }
        });

        Button buttonMultiplicacao = findViewById(R.id.btnMulti);
        buttonMultiplicacao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent telaCalcular = new Intent(MainActivity.this, Calcula.class);
                telaCalcular.putExtra("operacao","Multiplicar");
                startActivity(telaCalcular);
            }
        });

        Button buttonDivisao = findViewById(R.id.btnDiv);
        buttonDivisao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent telaCalcular = new Intent(MainActivity.this, Calcula.class);
                telaCalcular.putExtra("operacao","Dividir");
                startActivity(telaCalcular);
            }
        });
}
}