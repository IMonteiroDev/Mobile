package com.example.calculadora;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Menu extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

//        handleOnClick();


        Button btnReturn = findViewById(R.id.btnSair);
        Button btnSum = findViewById(R.id.btnAdicao);
        Button btnMinus = findViewById(R.id.btnSubstracao);
        Button btnDiv = findViewById(R.id.btnDiv);
        Button btnMult = findViewById(R.id.btnMulti);


        btnReturn.setOnClickListener(this);
        btnSum.setOnClickListener(this);
        btnMinus.setOnClickListener(this);
        btnDiv.setOnClickListener(this);
        btnMult.setOnClickListener(this);

    }

    private void handleOnClick(){
        Button btnReturn = findViewById(R.id.btnInicio);
        btnReturn.setOnClickListener(new View.OnClickListener(){
            @Override
                    public void onClick(View v){
                        Intent returnHome = new Intent();
            }
        });
    }


    @Override
    public void onClick(View v) {
        if(v.getId() == R.id.btnSair){
            Intent returnHome = new Intent(this, MainActivity.class);
            startActivity(returnHome);
        }
        if (v.getId()== R.id.btnAdicao){
            Intent sum = new Intent(this, Calcula.class);
            startActivity(sum);
        }
/*        if (v.getId()== R.id.btnMinus){
            Intent minus = new Intent(this, );
            startActivity(minus);
        }
        if (v.getId()== R.id.btnDiv){
            Intent div = new Intent(this, );
            startActivity(div);
        }
        if (v.getId()== R.id.btnMult){
            Intent multi = new Intent(this, );
            startActivity(multi);
        }
*/
    }
}