package com.example.calculadora;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Calcula extends AppCompatActivity implements View.OnClickListener{
    TextView txtTitulo;
    EditText editVal1;
    EditText editVal2;
    Button btnCalcular;
    Button btnVoltar;

    private String parametro = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calcula);

        txtTitulo = findViewById(R.id.txtTitulo);
        editVal1 = findViewById(R.id.editVal1);
        editVal2 = findViewById(R.id.editVal2);

        btnCalcular = findViewById(R.id.btnCalcular);
        btnCalcular.setOnClickListener(this);
        btnVoltar = findViewById(R.id.btnVoltar);
        btnVoltar.setOnClickListener(this);

        Intent homePage = getIntent();
        this.parametro = homePage.getStringExtra("operacao");
    }

    @Override
    public void onClick(View v) {
        if(v.getId()== R.id.btnVoltar){
            finish();
        } else if (v.getId() == R.id.btnCalcular) {
            int n1 = Integer.parseInt(editVal1.getText().toString());
            int n2 = Integer.parseInt(editVal2.getText().toString());
            int result = 0;

            switch (this.parametro){
                case "Somar":
                    result = n1+n2;
                    break;

                case "Subtrair":
                    result = n1-n2;
                    txtTitulo.setText("Subtrair números");
                    break;

                case "Multiplicar":
                    result = n1*n2;
                    txtTitulo.setText("Multiplicar números");
                    break;

                case "Dividir":
                    result = n1/n2;
                    txtTitulo.setText("Dividir números");
                    break;

            }
            Toast.makeText(this, "O Resultado é: "+result, Toast.LENGTH_LONG).show();
        }
    }
}